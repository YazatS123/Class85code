
export const firebaseConfig = {
  apiKey: "AIzaSyBbtod7S-2ZCWUl4Uio_MFU6c7pppyb9vg",
  authDomain: "storytelling-app-68754.firebaseapp.com",
  projectId: "storytelling-app-68754",
  storageBucket: "storytelling-app-68754.appspot.com",
  messagingSenderId: "324331758490",
  appId: "1:324331758490:web:b3cc08fc28520b4c4bd023"
};
